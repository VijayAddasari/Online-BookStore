from django.apps import AppConfig


class BooksappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'BooksApp'
